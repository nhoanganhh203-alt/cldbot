# -*- coding: utf-8 -*-
"""
============================================================
  VN DOMAIN HUNTER  v3.1 — AI-Powered Cyberpunk Edition
  Real-time live processing log + AI Threat Intelligence
============================================================
"""

import re
import math
import asyncio
import json
import threading
import os
import sys
import socket
from datetime import datetime
from typing import Optional
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from fastapi import FastAPI, UploadFile, File, Request, Response, Depends, HTTPException, status
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse, RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import secrets

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ──────────────────────────────────────────────────────────
# DNS Executor & DNS Check Function
dns_executor = ThreadPoolExecutor(max_workers=25)

def check_dns(domain: str) -> dict:
    try:
        ips = []
        # Chạy getaddrinfo nhanh với cổng 80
        addr_infos = socket.getaddrinfo(domain, 80, proto=socket.IPPROTO_TCP)
        for info in addr_infos:
            ip = info[4][0]
            if ip not in ips:
                ips.append(ip)
        return {"dns_active": len(ips) > 0, "ips": ips}
    except Exception:
        return {"dns_active": False, "ips": []}


# ──────────────────────────────────────────────────────────
app = FastAPI(title="Vinamilk Night Club", version="3.2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ──────────────────────────────────────────────────────────
# ADMIN AUTHENTICATION SYSTEM
ADMIN_USER = "admin"
ADMIN_PASS = "admin_vnmscan_2026"
ACTIVE_SESSIONS = set()

def get_current_admin(request: Request):
    session_id = request.cookies.get("vnmscan_session")
    if not session_id or session_id not in ACTIVE_SESSIONS:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthorized"
        )
    return ADMIN_USER

# ──────────────────────────────────────────────────────────
class ScanState:
    def __init__(self):
        self.running         = False
        self.results: list[dict] = []
        self.plain_results: list[str] = []
        self.original_filename = ""
        self.stop_event      = threading.Event()
        self.total_scanned   = 0
        self.total_found     = 0
        self.total_skipped   = 0
        self.scan_complete   = False

state = ScanState()

# ══════════════════════════════════════════════════════════
#  DETECTION RULES DATABASE
# ══════════════════════════════════════════════════════════

VN_TLD_PATTERN = re.compile(
    r'\.(vn|com\.vn|edu\.vn|gov\.vn|net\.vn|org\.vn|int\.vn|'
    r'ac\.vn|biz\.vn|info\.vn|name\.vn|pro\.vn|health\.vn|id\.vn)$',
    re.IGNORECASE
)

KEYWORD_GROUPS = {
    "banking": [
        "vietcombank","vcb","techcombank","tcb","bidv","agribank",
        "vietinbank","mbbank","mb-bank","sacombank","vpbank","tpbank",
        "acb-bank","hdbank","ocb","seabank","pvcombank","abbank","ncb","msb",
        "momo","momovn","zalopay","vnpay","vietqr","napas","ngan-luong",
        "nganluong","viettelpay","e-wallet","ewallet","ngan-hang","nganhang",
        "internet-banking","ibank","ebanking","atm-viet","the-tin-dung",
        "vcbbank","tcbbank","bidvbank","agribankvn","vietinbankvn","mbbankvn",
        "sacombankvn","vpbankvn","acbbank","shb","shbbank","tpbbank",
        "hdbankvn","vib","vibbank","msbbank","seabankvn","lpbank","lpbankvn",
        "ocbbank","baovietbank","scb","scbbank","eximbank","eximbankvn",
        "namabank","pgbank","vietbank","vietacabank","kienlongbank","saigonbank",
        "ncbbank","cbbank","oceanbank","gpbank","kredivo","kredivovn",
        "vimo","payoo","moca","smartpay","viettelmoney","vnptmoney",
        "shopeepay","shopeepayvn","grabpay","applepay","googlepay",
        "samsungpay","alipay","wechatpay","napas247"
    ],
    "ecommerce": [
        "shopee","lazada","tiki","sendo","thegioididong","cellphones",
        "fptshop","nguyenkim","bachhoaxanh","dienmayxanh","mediamart",
        "hoanghamobile","websosanh","vatgia","muaban","chotot","nhattao",
    ],
    "social_media": [
        "zalo","zalovn","zalo-vn","facebook-vn","facebookvn","fb-support",
        "fbsupport","fb-viet","fb-vietnam","youtube-vn","tiktok-vn",
        "tiktok-vietnam","instagram-vn","telegram-vn","zalo-me","zalome",
        "zalo-chat","zalochat","zalo-pc","zalopc","zalo-web","zaloweb",
        "facebook-support","fb-meta","meta-vn","meta-vietnam","tele-vn",
        "tele-viet","telegram-viet"
    ],
    "media_news": [
        "vtv","vtv1","vtv3","vtcnow","vnexpress","tuoitre","dantri",
        "zing","zingnews","thanhnien","nguoiduatin","kenh14","soha",
        "laodong","baomoi","cafef",
    ],
    "government": [
        "cong-an","congan","canhsat","bocongan","mps-vn","thue","toaan",
        "vksnd","tand","vienvksnd","chinhphu","chinh-phu","bo-tai-chinh",
        "botaichinh","bhxhvn","bhxh-vn","haiquan","customs-vn","so-giao-duc",
        "dich-vu-cong","dichvucong","vneid","vneid-gov","vneidgov",
        "dichvucong-gov","dichvuconggov","bhxh","bao-hiem-xa-hoi","baohiemxahoi",
        "kiem-tra-phat-nguoi","phatnguoi","phat-nguoi"
    ],
    "telecom": [
        "viettel","vietteltelecom","mobifone","mobifonevn","vinaphone",
        "vnpt","vietnamobile","gmobile","reddi",
    ],
    "phishing_traps": [
        "qua-tang","quatang","trung-thu","trungthu","tuyen-dung","tuyendung",
        "viec-lam","vieclam","kiem-tien","kiemtien","lam-giau","lamgiau",
        "trung-thuong","trungthuong","nhan-thuong","dat-cuoc","datcuoc",
        "casino-vn","casinovn","lo-de","lode","xo-so","xoso","tai-khoan",
        "taikhoan","mat-khau","matkhau","dang-nhap","dangnhap","login-vn",
        "loginvn","verify-vn","xac-minh","xacminh","bao-mat","baomatvn",
        "security-vn","ho-tro","hotro","support-vn","mien-phi","mienphi",
        "uu-dai","uudai","khuyen-mai","khuyenmai","nap-tien","naptien",
        "rut-tien","ruttien","giao-dich","giaodich","chuyen-tien","chuyentien",
        "dau-tu","dautu","loi-nhuan","loinhuan","thanh-toan","thanhtoan",
        "vn-pay","bong-da","bongda","the-thao",
        "giao-hang","giaohang","buu-dien","buudien","nhan-hang","nhanhang",
        "ghtk","viettelpost","vnpost","vn-post","ems-vn","ninja-van","ninjavan",
        "j-t","jandt","giao-hang-nhanh","giaohangnhanh","giao-hang-tiet-kiem",
        "giaohangtietkiem","cong-tac-vien","congtacvien","ctv-shopee",
        "ctvlazada","lam-nhiem-vu","lamnhiemvu","giat-don","giatdonhang",
        "mua-don-hang","xem-video-kiem-tien","tiktok-kiem-tien","nohu",
        "no-hu","no-hu-club","sunwin","sun-win","go88","go-88","rikvip",
        "rik-vip","b52","b52-club","789bet","789-bet","shbet","new88",
        "jun88","f8bet","hi88","ae888","fi88","w88","fun88","fb88",
        "m88","188bet","kabs","kubet","ku-bet","thabet","tha-bet","tj77",
        "lvs788","vay-tien-nhanh","vaytiennhanh","vay-nong","vaynong",
        "vay-online","vayonline","app-vay","appvay","tin-dung-den","tindungden",
        "vay-tin-chap","vaytinchap","f88","f88-vay","dong-247","dong247",
        "doctordong","doctor-dong","tamo","tamovn","findo","findovn",
        "senmo","senmovn","robocash","moneycat","atm-online","atmonline"
    ],
    "geography": [
        "viet","vietnam","viet-nam","hanoi","ha-noi","hochiminh","hcm",
        "saigon","danang","da-nang","hue-vn","cantho","hai-phong","haiphong",
        "bien-hoa","nha-trang","vung-tau","da-lat","dalat","buon-ma-thuot",
    ],
    "crypto_scam": [
        "dau-tu-coin","coin-vn","bitcoin-vn","crypto-vn","nft-vn","defi-vn",
        "metaverse-vn","web3-vn","mining-vn","airdrop-vn","binance-vn",
        "pi-network","pinetwork","pi-coin","ico-vn","defi-viet","future-vn",
        "forex-vn","exness-vn","binance-viet","mexc-vn","bybit-vn","okx-vn"
    ],
}

ALL_VN_KEYWORDS: list[str] = []
KW_TO_GROUP: dict[str, str] = {}
for grp, kws in KEYWORD_GROUPS.items():
    for kw in kws:
        ALL_VN_KEYWORDS.append(kw)
        KW_TO_GROUP[kw] = grp

VN_KEYWORD_PATTERN = re.compile(
    '|'.join(re.escape(kw) for kw in sorted(ALL_VN_KEYWORDS, key=len, reverse=True)),
    re.IGNORECASE
)

def check_keyword_match(domain: str) -> Optional[dict]:
    """
    Kiểm tra xem domain có chứa từ khóa Việt Nam nào không.
    Áp dụng ranh giới từ chặt chẽ cho các từ khóa ngắn (<= 5 ký tự) để chống false positive.
    Trả về dict {'kw': kw, 'group': group} hoặc None.
    """
    domain_lower = domain.lower()
    parts = domain_lower.split('.')
    if len(parts) > 1 and parts[-1] not in ('vn', 'com', 'net', 'org', 'edu', 'gov', 'biz', 'info', 'name', 'pro', 'vn'):
        label_part = ".".join(parts[:-1])
    elif len(parts) > 1:
        label_part = ".".join(parts[:-1])
    else:
        label_part = domain_lower

    for kw in sorted(ALL_VN_KEYWORDS, key=len, reverse=True):
        kw_lower = kw.lower()
        if kw_lower not in label_part:
            continue
        
        # Nếu là từ khóa ngắn (<= 5 ký tự)
        if len(kw_lower) <= 5:
            pattern = re.compile(rf'(?<![a-z]){re.escape(kw_lower)}(?![a-z])')
            if pattern.search(label_part):
                return {"kw": kw, "group": KW_TO_GROUP[kw]}
        else:
            return {"kw": kw, "group": KW_TO_GROUP[kw]}
            
    return None

SKIP_PATTERN   = re.compile(r'^\s*(#|!|\[)')
IP_PREFIX      = re.compile(r'^\s*(0\.0\.0\.0|127\.0\.0\.1|::1|localhost)\s+')
DOMAIN_EXTRACT = re.compile(
    r'\b([a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?'
    r'(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*'
    r'\.[a-zA-Z]{2,})\b',
    re.IGNORECASE
)
PURE_IP_RE = re.compile(r'^[\d.]+$')
IDN_RE     = re.compile(r'^xn--', re.IGNORECASE)

LEET_MAP = str.maketrans({'0':'o','1':'l','3':'e','4':'a','5':'s','6':'g','7':'t','8':'b','9':'q','@':'a','$':'s'})

LEGIT_BRANDS = [
    "vietcombank","techcombank","bidv","agribank","vietinbank","mbbank",
    "sacombank","vpbank","momo","zalopay","vnpay","shopee","lazada","tiki",
    "zalo","viettel","mobifone","vinaphone","vtv","vnexpress",
    "facebook","google","youtube","tiktok","instagram",
]

SUSPICIOUS_PATTERNS = [
    (re.compile(r'\d{5,}'),                                                    5, "Chuoi so dai"),
    (re.compile(r'(-[a-z]{1,3}){3,}'),                                        4, "Qua nhieu doan hyphen"),
    (re.compile(r'(login|signin|verify|secure|update|confirm|alert)', re.I),   6, "Tu hanh dong phishing"),
    (re.compile(r'(free|gift|win|prize|bonus|reward)', re.I),                  4, "Tu du do"),
    (re.compile(r'(support|help|service|customer)', re.I),                     3, "Gia mao dich vu"),
    (re.compile(r'(account|password|passwd|credential)', re.I),                5, "Thu thap thong tin"),
    (re.compile(r'(pay|payment|invoice|billing|checkout)', re.I),              5, "Hanh dong tai chinh"),
    (re.compile(r'\.tk$|\.ml$|\.ga$|\.cf$|\.gq$', re.I),                      8, "TLD mien phi (phishing)"),
    (re.compile(r'\.(xyz|top|click|link|site|online|space|fun)$', re.I),       5, "TLD dang nghi"),
    (re.compile(r'xn--[a-z0-9]+', re.I),                                       7, "IDN/Punycode"),
]

# ══════════════════════════════════════════════════════════
#  AI THREAT INTELLIGENCE ENGINE
# ══════════════════════════════════════════════════════════

def shannon_entropy(s: str) -> float:
    if not s: return 0.0
    freq = Counter(s)
    total = len(s)
    return -sum((c/total)*math.log2(c/total) for c in freq.values())

def levenshtein(a: str, b: str) -> int:
    if a == b: return 0
    if len(a) < len(b): a, b = b, a
    prev = list(range(len(b)+1))
    for ca in a:
        curr = [prev[0]+1]
        for j, cb in enumerate(b):
            curr.append(min(prev[j+1]+1, curr[j]+1, prev[j]+(ca!=cb)))
        prev = curr
    return prev[-1]

def detect_leet(domain: str) -> Optional[str]:
    label = domain.split('.')[0]
    norm  = label.translate(LEET_MAP)
    for brand in LEGIT_BRANDS:
        if brand in norm and brand not in label:
            return brand
    return None

def detect_typo(domain: str) -> Optional[tuple]:
    label = domain.split('.')[0].lower()
    if len(label) < 4: return None
    for brand in LEGIT_BRANDS:
        if abs(len(label)-len(brand)) > 2: continue
        d = levenshtein(label, brand)
        if 1 <= d <= 2: return (brand, d)
    return None

def ai_analyze(domain: str) -> dict:
    score = 0
    signals: list[str] = []
    categories: list[str] = []
    matched_keywords: list[str] = []

    if VN_TLD_PATTERN.search(domain):
        score += 20
        signals.append("TLD .vn / .com.vn / .gov.vn ...")
        categories.append("VN_TLD")

    kw_match = check_keyword_match(domain)
    if kw_match:
        kw = kw_match["kw"]
        grp = kw_match["group"]
        matched_keywords.append(kw)
        if grp not in categories:
            categories.append(grp)
        w = {"banking":30,"government":25,"phishing_traps":22,"crypto_scam":20,
             "social_media":18,"telecom":18,"ecommerce":15,"media_news":12,"geography":8}
        score += w.get(grp, 10)
        signals.append(f'Tu khoa [{kw}] -> [{grp}]')

    for pat, pts, label in SUSPICIOUS_PATTERNS:
        if pat.search(domain):
            score += pts
            signals.append(f"Pattern: {label}")

    label_part = domain.split('.')[0]
    depth      = domain.count('.') - 1
    entropy    = shannon_entropy(label_part)

    if depth >= 3:
        score += depth * 4
        signals.append(f"Subdomain sau ({depth} cap)")

    if entropy > 3.8:
        score += int((entropy - 3.8) * 10)
        signals.append(f"Entropy cao ({entropy:.2f}) - co the DGA")

    if len(domain) > 50:
        score += 8
        signals.append(f"Domain qua dai ({len(domain)} ky tu)")
    elif len(domain) > 35:
        score += 4

    leet_t = detect_leet(domain)
    if leet_t:
        score += 18
        signals.append(f"Leet-speak gia mao '{leet_t}'")
        if "homograph_attack" not in categories: categories.append("homograph_attack")

    typo = detect_typo(domain)
    if typo:
        score += 20
        signals.append(f"Typosquat cua '{typo[0]}' (khoang cach={typo[1]})")
        if "typosquatting" not in categories: categories.append("typosquatting")

    if IDN_RE.search(domain):
        score += 15
        signals.append("Punycode/IDN - nguy co homograph")
        if "homograph_attack" not in categories: categories.append("homograph_attack")

    digits = sum(c.isdigit() for c in label_part)
    ratio  = digits / max(len(label_part), 1)
    if ratio > 0.4:
        score += 8
        signals.append(f"Ty le so cao ({ratio:.0%})")

    if len(categories) >= 3:
        score += 10
        signals.append("Nhieu danh muc trung lap - do tin cay cao")

    score = min(score, 100)

    if score >= 75: risk, risk_color = "CRITICAL", "#ff2244"
    elif score >= 55: risk, risk_color = "HIGH",     "#ff8800"
    elif score >= 35: risk, risk_color = "MEDIUM",   "#ffe000"
    else:             risk, risk_color = "LOW",       "#00d2ff"

    primary = categories[0] if categories else "unknown"
    cat_labels = {
        "banking":"Banking Fraud","ecommerce":"E-Commerce Spoof",
        "social_media":"Social Media Spoof","media_news":"News Media Spoof",
        "government":"Govt Impersonation","telecom":"Telecom Fraud",
        "phishing_traps":"Phishing Trap","geography":"VN Geography Lure",
        "crypto_scam":"Crypto Scam","homograph_attack":"Homograph Attack",
        "typosquatting":"Typosquatting","VN_TLD":"VN TLD Domain","unknown":"Unknown Threat",
    }

    return {
        "score": score, "risk": risk, "risk_color": risk_color,
        "primary_category": cat_labels.get(primary, primary),
        "all_categories": [cat_labels.get(c, c) for c in categories],
        "matched_keywords": matched_keywords,
        "signals": signals,
        "entropy": round(entropy, 2),
        "subdomain_depth": depth,
    }

# ══════════════════════════════════════════════════════════
#  CORE FILTER + LIVE LOG GENERATOR
# ══════════════════════════════════════════════════════════

# How often to emit "log" events for non-matching lines
# Small files (<= 3000): every line; larger: every 100
LOG_INTERVAL_SMALL = 1
LOG_INTERVAL_LARGE = 100

def process_domains_with_log(
    raw_lines: list[str],
    limit: Optional[int],
    stop_event: threading.Event,
    enable_ai: bool = True,
    enable_dns: bool = False,
):
    """
    Generator — yields SSE dicts.
    Types: log | domain | progress | done | stopped
    """
    seen         = set()
    found        = 0
    scanned      = 0
    skipped_cmt  = 0
    skipped_ip   = 0
    skipped_dup  = 0
    skipped_novn = 0
    total        = len(raw_lines)
    is_small     = total <= 3000
    log_every    = LOG_INTERVAL_SMALL if is_small else LOG_INTERVAL_LARGE

    def make_log(icon: str, msg: str, color: str = "#8aa8c0", raw: str = ""):
        return {"type": "log", "icon": icon, "msg": msg, "color": color, "raw": raw[:80]}

    for line in raw_lines:
        if stop_event.is_set():
            yield {
                "type": "stopped",
                "scanned": scanned, "found": found,
                "skipped_cmt": skipped_cmt, "skipped_ip": skipped_ip,
                "skipped_dup": skipped_dup, "skipped_novn": skipped_novn,
                "message": f"STOP! Da quet {scanned:,}/{total:,} dong | Tim thay: {found:,}",
            }
            return

        scanned += 1
        state.total_scanned = scanned
        raw_display = line.strip()[:70]

        # ── Step 1: Empty check ─────────────────────────
        if not line.strip():
            if is_small and scanned % log_every == 0:
                yield make_log("⬜", f"[{scanned}] Dong trong — bo qua", "#444")
            continue

        # ── Step 2: Comment / header check ─────────────
        if SKIP_PATTERN.match(line.strip()):
            skipped_cmt += 1
            if is_small and scanned % log_every == 0:
                yield make_log("💬", f"[{scanned}] Ghi chu / header — bo qua: {raw_display}", "#555")
            continue

        # ── Step 3: Strip quotes/commas ─────────────────
        cleaned = line.strip().strip('"\'').strip(',').strip()

        # ── Step 4: Strip IP prefix ─────────────────────
        ip_match = IP_PREFIX.match(cleaned)
        ip_prefix_found = ""
        if ip_match:
            ip_prefix_found = ip_match.group(0).strip()
            cleaned = IP_PREFIX.sub('', cleaned).strip()

        # ── Step 5: Strip trailing comment ─────────────
        cleaned = re.split(r'\s+#', cleaned)[0].strip()

        # ── Step 6: Extract domain ──────────────────────
        dm = DOMAIN_EXTRACT.search(cleaned)
        if not dm:
            if is_small and scanned % log_every == 0:
                yield make_log("❌", f"[{scanned}] Khong tim thay domain: {raw_display}", "#555")
            continue

        domain = dm.group(0).lower().rstrip('.')

        if len(domain) < 4 or '.' not in domain or PURE_IP_RE.match(domain):
            if is_small and scanned % log_every == 0:
                yield make_log("🔇", f"[{scanned}] Domain khong hop le: {domain}", "#555")
            continue

        # ── Step 7: Duplicate check ─────────────────────
        if domain in seen:
            skipped_dup += 1
            if is_small and scanned % log_every == 0:
                yield make_log("🔁", f"[{scanned}] Trung lap — bo qua: {domain}", "#4a6478")
            continue

        # ── Step 8: VN target check ─────────────────────
        vn_tld  = bool(VN_TLD_PATTERN.search(domain))
        kw_res  = check_keyword_match(domain)
        vn_kw   = bool(kw_res)

        if not vn_tld and not vn_kw:
            skipped_novn += 1
            if is_small and scanned % log_every == 0:
                yield make_log("🌐", f"[{scanned}] Khong lien quan VN — loai: {domain}", "#3a5468")
            # Emit progress every log_every lines
            if scanned % (log_every * 20) == 0:
                yield {
                    "type": "progress",
                    "scanned": scanned, "found": found, "total": total,
                    "pct": round(scanned/total*100, 1),
                    "skipped_cmt": skipped_cmt, "skipped_dup": skipped_dup,
                    "skipped_novn": skipped_novn,
                }
            continue

        # ── MATCH FOUND ─────────────────────────────────
        seen.add(domain)
        found += 1
        state.total_found = found

        # Determine why it matched
        match_reason = ""
        if vn_tld and vn_kw:
            match_reason = "TLD .vn + Tu khoa VN"
        elif vn_tld:
            match_reason = "TLD .vn gia dinh"
        else:
            match_reason = f"Tu khoa: '{kw_res['kw']}'" if kw_res else "Tu khoa VN"

        if ip_prefix_found:
            clean_note = f" [Da xoa IP: {ip_prefix_found}]"
        else:
            clean_note = ""

        # Emit detailed log for this match
        yield make_log(
            "✅",
            f"[{scanned}] MATCH #{found} — {domain}{clean_note} | Ly do: {match_reason}",
            "#00ff88",
            raw_display,
        )

        # AI analysis
        ai = ai_analyze(domain) if enable_ai else {
            "score":0,"risk":"UNKNOWN","risk_color":"#888",
            "primary_category":"Unknown","all_categories":[],
            "matched_keywords":[],"signals":[],"entropy":0,"subdomain_depth":0,
        }

        if enable_ai and is_small:
            signals_short = " | ".join(ai["signals"][:3])
            yield make_log(
                "🤖",
                f"   AI Score: {ai['score']}/100 | Risk: {ai['risk']} | {ai['primary_category']} | {signals_short}",
                ai["risk_color"],
            )

        # DNS Check
        dns_status = {"dns_active": False, "ips": []}
        if enable_dns:
            dns_status = check_dns(domain)
            if dns_status["dns_active"]:
                ips_str = ", ".join(dns_status["ips"][:3])
                if is_small:
                    yield make_log(
                        "🌐",
                        f"   DNS Check: ACTIVE | IPs: {ips_str}",
                        "#00ff88",
                    )
            else:
                if is_small:
                    yield make_log(
                        "🌐",
                        f"   DNS Check: INACTIVE (Khong resolve duoc IP)",
                        "#ff2244",
                    )

        record = {
            "type": "domain",
            "domain": domain,
            "index": found,
            "scanned": scanned,
            "total": total,
            "skipped_cmt": skipped_cmt,
            "skipped_dup": skipped_dup,
            "skipped_novn": skipped_novn,
            "dns_active": dns_status["dns_active"],
            "ips": dns_status["ips"],
            **ai,
        }

        state.results.append(record)
        state.plain_results.append(domain)
        yield record

        if limit and found >= limit:
            yield {
                "type": "done",
                "scanned": scanned, "found": found,
                "skipped_cmt": skipped_cmt, "skipped_dup": skipped_dup,
                "skipped_novn": skipped_novn,
                "message": f"Dat gioi han {limit:,} domain! Tong quet: {scanned:,}/{total:,}",
            }
            return

        # Progress pulse after each match
        yield {
            "type": "progress",
            "scanned": scanned, "found": found, "total": total,
            "pct": round(scanned/total*100, 1),
            "skipped_cmt": skipped_cmt, "skipped_dup": skipped_dup,
            "skipped_novn": skipped_novn,
        }

    # Final summary log
    yield make_log("📊", f"TONG KET: Quet {scanned:,} dong | Tim thay: {found:,} | Comment: {skipped_cmt:,} | Trung lap: {skipped_dup:,} | Non-VN: {skipped_novn:,}", "#00d2ff")

    yield {
        "type": "done",
        "scanned": scanned, "found": found,
        "skipped_cmt": skipped_cmt, "skipped_dup": skipped_dup,
        "skipped_novn": skipped_novn,
        "message": f"HOAN TAT! Quet {scanned:,}/{total:,} dong — Tim thay {found:,} domain VN",
    }

# ══════════════════════════════════════════════════════════
#  API ENDPOINTS
# ══════════════════════════════════════════════════════════

@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...), admin: str = Depends(get_current_admin)):
    content = await file.read()
    try:    text = content.decode("utf-8")
    except: text = content.decode("latin-1", errors="replace")
    lines = text.splitlines()
    state.original_filename = os.path.splitext(file.filename or "domains")[0]
    # Count different line types for preview
    comments = sum(1 for l in lines if l.strip() and SKIP_PATTERN.match(l.strip()))
    empties  = sum(1 for l in lines if not l.strip())
    return JSONResponse({
        "status": "ok",
        "filename": file.filename,
        "line_count": len(lines),
        "comments": comments,
        "empties": empties,
        "data_lines": len(lines) - comments - empties,
        "preview": lines[:8],
    })


@app.post("/api/scan-stream")
async def scan_stream(request: Request, admin: str = Depends(get_current_admin)):
    body      = await request.json()
    lines     = body.get("lines", [])
    limit_raw = body.get("limit", None)
    enable_ai = body.get("enable_ai", True)
    enable_dns = body.get("enable_dns", False)
    limit     = int(limit_raw) if limit_raw and str(limit_raw).strip() else None

    state.running       = True
    state.results       = []
    state.plain_results = []
    state.stop_event.clear()
    state.scan_complete  = False
    state.total_scanned  = 0
    state.total_found    = 0

    async def event_generator():
        loop  = asyncio.get_event_loop()
        queue: asyncio.Queue = asyncio.Queue()

        def run_scan():
            for item in process_domains_with_log(lines, limit, state.stop_event, enable_ai, enable_dns):
                asyncio.run_coroutine_threadsafe(queue.put(item), loop)
            asyncio.run_coroutine_threadsafe(queue.put(None), loop)

        thread = threading.Thread(target=run_scan, daemon=True)
        thread.start()

        try:
            while True:
                item = await queue.get()
                if item is None:
                    state.running      = False
                    state.scan_complete = True
                    break
                yield f"data: {json.dumps(item, ensure_ascii=False)}\n\n"
        except asyncio.CancelledError:
            state.stop_event.set()
            state.running = False

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.post("/api/stop")
async def stop_scan(admin: str = Depends(get_current_admin)):
    state.stop_event.set()
    state.running = False
    return JSONResponse({"status": "stopped"})


@app.get("/api/download")
async def download_results(fmt: str = "txt", admin: str = Depends(get_current_admin)):
    now       = datetime.now()
    ts        = now.strftime("%H-%M-%S_%d-%m-%Y")
    base      = state.original_filename or "domains"
    if fmt == "json":
        fname   = f"{base}_VietNam_{ts}.json"
        content = json.dumps(state.results, ensure_ascii=False, indent=2)
        content_bytes = content.encode("utf-8")
        ctype   = "application/json"
    elif fmt == "csv":
        fname   = f"{base}_VietNam_{ts}.csv"
        csv_headers = "Index,Domain,Risk Level,Risk Score,Primary Category,Keywords,DNS Status,IPs,Entropy,Subdomain Depth,Signals"
        csv_rows = [csv_headers]
        for r in state.results:
            domain = r.get("domain", "")
            risk = r.get("risk", "LOW")
            score = r.get("score", 0)
            category = r.get("primary_category", "Unknown")
            kws = "; ".join(r.get("matched_keywords", []))
            dns_status = "ACTIVE" if r.get("dns_active", False) else "INACTIVE"
            ips = "; ".join(r.get("ips", []))
            entropy = r.get("entropy", 0.0)
            depth = r.get("subdomain_depth", 0)
            signals = "; ".join(r.get("signals", []))
            csv_rows.append(f'"{r.get("index", 0)}","{domain}","{risk}","{score}","{category}","{kws}","{dns_status}","{ips}","{entropy}","{depth}","{signals}"')
        
        content = "\r\n".join(csv_rows)
        content_bytes = content.encode("utf-8-sig")
        ctype   = "text/csv"
    else:
        fname   = f"{base}_VietNam_{ts}.txt"
        content = "\n".join(state.plain_results)
        content_bytes = content.encode("utf-8")
        ctype   = "text/plain"
        
    return StreamingResponse(
        iter([content_bytes]),
        media_type=ctype,
        headers={
            "Content-Disposition": f'attachment; filename="{fname}"',
            "Content-Type": f"{ctype}; charset=utf-8",
        },
    )


@app.get("/api/analyze")
async def analyze_single(domain: str, admin: str = Depends(get_current_admin)):
    d = domain.strip().lower()
    if not d: return JSONResponse({"error":"No domain"}, status_code=400)
    result = ai_analyze(d)
    result["domain"] = d
    result["is_vn_target"] = bool(VN_TLD_PATTERN.search(d) or VN_KEYWORD_PATTERN.search(d))
    return JSONResponse(result)


@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    session_id = request.cookies.get("vnmscan_session")
    if not session_id or session_id not in ACTIVE_SESSIONS:
        return RedirectResponse(url="/login")
    with open("index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())


@app.get("/login", response_class=HTMLResponse)
async def get_login():
    with open("login.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())


@app.post("/api/login")
async def api_login(request: Request, response: Response):
    body = await request.json()
    username = body.get("username")
    password = body.get("password")
    if username and password and secrets.compare_digest(username, ADMIN_USER) and secrets.compare_digest(password, ADMIN_PASS):
        session_id = secrets.token_hex(32)
        ACTIVE_SESSIONS.add(session_id)
        response.set_cookie(key="vnmscan_session", value=session_id, httponly=True, samesite="lax")
        return {"status": "ok", "message": "Login successful"}
    return JSONResponse({"status": "error", "message": "Invalid username or password"}, status_code=400)


@app.get("/logout")
async def logout(request: Request, response: Response):
    session_id = request.cookies.get("vnmscan_session")
    if session_id in ACTIVE_SESSIONS:
        ACTIVE_SESSIONS.remove(session_id)
    response.delete_cookie(key="vnmscan_session")
    return RedirectResponse(url="/login")


if __name__ == "__main__":
    print("=" * 60)
    print("  Vinamilk Night Club v3.2 - AI Cyberpunk Edition")
    print("  http://localhost:8000")
    print("=" * 60)
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=False)
